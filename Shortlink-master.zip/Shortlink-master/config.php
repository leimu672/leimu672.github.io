<?php

  global $config;
  $config = [];

  // 程序安装路径
  $config['path'] = '/';
  // ID 长度
  $config['length'] = 8;
  // 网站标题
  $config['title'] = '短链生成';
  // 网站简介
  $config['description'] = '在线网址缩短服务';
  
  $config['api'] = true;

?>
